package net.furculita.util;

public class TSPException extends Exception {
    public TSPException() {
        super();
    }
    public TSPException(String message) {
        super(message);
    }
}