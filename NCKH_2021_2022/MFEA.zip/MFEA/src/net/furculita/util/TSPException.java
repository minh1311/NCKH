package net.furculita.util;

public class TSPException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4428369034785174217L;

	public TSPException() {
	}

	public TSPException(String message) {
		super(message);
	}

}
